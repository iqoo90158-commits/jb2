package com.example.jailbreak

import android.content.Context

/** Общее состояние «живых событий» для острова lala: музыка и звонок. */
object Live {
    data class Media(val title: String, val artist: String)
    data class Call(val name: String, val startMs: Long, val ringing: Boolean)

    @Volatile var media: Media? = null
    @Volatile var call: Call? = null

    /** Остров подписывается сюда, чтобы перерисоваться. */
    @Volatile var onChange: (() -> Unit)? = null

    /** Слушатель уведомлений подписывается сюда, чтобы пересчитать музыку после смены настроек. */
    @Volatile var refresh: (() -> Unit)? = null

    fun changed() {
        onChange?.invoke()
    }

    /** Вызывать после изменения любой опции lala. */
    fun optionChanged(ctx: Context) {
        if (!Prefs.get(ctx, Prefs.K_L_CALL, true)) call = null
        refresh?.invoke()
        changed()
    }
}
