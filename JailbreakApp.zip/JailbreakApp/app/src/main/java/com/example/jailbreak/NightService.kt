package com.example.jailbreak

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

/**
 * Ночной фильтр: тёплый полупрозрачный слой поверх всего экрана.
 * Яркость и цвет самого экрана не меняются — это просто цветная плёнка.
 */
class NightService : Service() {

    companion object {
        @Volatile
        var instance: NightService? = null
            private set

        fun start(c: Context) {
            try {
                c.startForegroundService(Intent(c, NightService::class.java))
            } catch (_: Throwable) {
            }
        }

        fun stop(c: Context) {
            try {
                c.stopService(Intent(c, NightService::class.java))
            } catch (_: Throwable) {
            }
        }

        /** Перекрашивает уже показанный слой, если служба запущена. */
        fun refresh(c: Context) {
            val s = instance
            if (s != null) s.applyLevel()
            else if (Prefs.get(c, Prefs.K_NIGHT)) start(c)
        }

        /** 0 — мягкий, 1 — средний, 2 — сильный. */
        fun alphaFor(level: Int): Int = when (level) {
            0 -> 26    // ≈10 %
            2 -> 77    // ≈30 %
            else -> 48 // ≈19 %
        }
    }

    private var layer: View? = null
    private var wm: WindowManager? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        startAsForeground()
        showLayer()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(
                "night",
                getString(R.string.tweak_night_name),
                NotificationManager.IMPORTANCE_MIN
            )
        )
        val n = Notification.Builder(this, "night")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.night_running))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(3, n)
        }
    }

    private fun showLayer() {
        if (!Settings.canDrawOverlays(this)) return
        val level = Prefs.getInt(this, Prefs.K_NIGHT_LEVEL, 1)
        val v = View(this).apply {
            background = ColorDrawable(Color.argb(alphaFor(level), 255, 166, 66))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }
        try {
            val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            w.addView(v, lp)
            layer = v
            wm = w
        } catch (_: Throwable) {
        }
    }

    fun applyLevel() {
        val level = Prefs.getInt(this, Prefs.K_NIGHT_LEVEL, 1)
        (layer?.background as? ColorDrawable)?.color = Color.argb(alphaFor(level), 255, 166, 66)
    }

    override fun onDestroy() {
        try {
            layer?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        layer = null
        wm = null
        if (instance === this) instance = null
        super.onDestroy()
    }
}
