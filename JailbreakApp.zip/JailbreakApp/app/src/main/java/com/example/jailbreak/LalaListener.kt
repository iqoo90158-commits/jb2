package com.example.jailbreak

import android.app.Notification
import android.content.ComponentName
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Источник событий для острова lala и подсветки Aurora:
 * уведомления, музыка (медиасессии) и звонки.
 */
class LalaListener : NotificationListenerService() {

    private var msm: MediaSessionManager? = null
    private var controllers: List<MediaController> = emptyList()
    private var callKey: String? = null

    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = refreshMedia()
        override fun onMetadataChanged(metadata: MediaMetadata?) = refreshMedia()
    }

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> bind(list ?: emptyList()) }

    private fun on(key: String) =
        Prefs.jailbroken(this) && Prefs.get(this, Prefs.K_LALA) && Prefs.get(this, key, true)

    // ───────────── подключение ─────────────

    override fun onListenerConnected() {
        super.onListenerConnected()
        Live.refresh = { refreshMedia() }
        try {
            val m = getSystemService(MediaSessionManager::class.java)
            msm = m
            val cn = ComponentName(this, LalaListener::class.java)
            m.addOnActiveSessionsChangedListener(sessionsListener, cn)
            bind(m.getActiveSessions(cn))
        } catch (_: Throwable) {
        }
        try {
            activeNotifications?.forEach { handleCall(it) }
        } catch (_: Throwable) {
        }
    }

    override fun onListenerDisconnected() {
        try {
            msm?.removeOnActiveSessionsChangedListener(sessionsListener)
        } catch (_: Throwable) {
        }
        controllers.forEach {
            try {
                it.unregisterCallback(mediaCb)
            } catch (_: Throwable) {
            }
        }
        controllers = emptyList()
        Live.media = null
        Live.call = null
        Live.refresh = null
        Live.changed()
        super.onListenerDisconnected()
    }

    // ───────────── музыка ─────────────

    private fun bind(list: List<MediaController>) {
        controllers.forEach {
            try {
                it.unregisterCallback(mediaCb)
            } catch (_: Throwable) {
            }
        }
        controllers = list
        list.forEach {
            try {
                it.registerCallback(mediaCb)
            } catch (_: Throwable) {
            }
        }
        refreshMedia()
    }

    private fun refreshMedia() {
        val playing = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
        Live.media = if (on(Prefs.K_L_MUSIC) && playing != null) {
            val md = playing.metadata
            val title = md?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
            val artist = (md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
                ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)).orEmpty()
            Live.Media(title, artist)
        } else {
            null
        }
        Live.changed()
    }

    // ───────────── звонки ─────────────

    /** Возвращает true, если это уведомление о звонке (оно не показывается как обычное). */
    private fun handleCall(sbn: StatusBarNotification): Boolean {
        val n = sbn.notification ?: return false
        if (n.category != Notification.CATEGORY_CALL) return false
        if (!on(Prefs.K_L_CALL)) return true

        val ex = n.extras
        val name = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
        val chrono = ex.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER, false)
        val type = if (Build.VERSION.SDK_INT >= 31) ex.getInt(Notification.EXTRA_CALL_TYPE, 0) else 0
        // 1 — входящий, 2 — идёт разговор, 3 — проверка вызова; иначе по секундомеру
        val ringing = when (type) {
            1, 3 -> true
            2 -> false
            else -> !chrono
        }
        val start = if (n.`when` > 0) n.`when` else System.currentTimeMillis()
        callKey = sbn.key
        Live.call = Live.Call(name, start, ringing)
        Live.changed()
        return true
    }

    // ───────────── уведомления ─────────────

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.jailbroken(this)) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return

        if (handleCall(sbn)) return
        if (n.category == Notification.CATEGORY_TRANSPORT) return // музыка идёт отдельно
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        if (on(Prefs.K_L_NOTIF)) {
            val extras = n.extras
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val line = listOf(title, text).filter { it.isNotBlank() }.joinToString(" · ")
            if (line.isNotBlank()) IslandService.instance?.pop(line)
        }

        if (Prefs.get(this, Prefs.K_AURA)) {
            Aurora.flash(this, sbn.packageName)
        }
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification) {
        if (sbn.key == callKey) {
            callKey = null
            Live.call = null
            Live.changed()
        }
    }
}
