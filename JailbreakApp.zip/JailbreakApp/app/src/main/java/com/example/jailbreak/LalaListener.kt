package com.example.jailbreak

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/** Передаёт входящие уведомления в остров lala и подсветку Aurora. */
class LalaListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.jailbroken(this)) return
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        if (n.flags and Notification.FLAG_ONGOING_EVENT != 0) return
        if (n.flags and Notification.FLAG_GROUP_SUMMARY != 0) return

        if (Prefs.get(this, Prefs.K_LALA)) {
            val extras = n.extras
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            val line = listOf(title, text).filter { it.isNotBlank() }.joinToString(" · ")
            if (line.isNotBlank()) IslandService.instance?.pop(line)
        }

        if (Prefs.get(this, Prefs.K_AURA)) {
            Aurora.flash(this)
        }
    }
}
