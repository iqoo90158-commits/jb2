package com.example.jailbreak

import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView

/**
 * lala: чёрная «таблетка» вокруг фронтальной камеры.
 * В покое повторяет форму выреза, при уведомлении плавно раскрывается.
 */
class IslandService : Service() {

    companion object {
        @Volatile
        var instance: IslandService? = null

        fun start(c: Context) {
            c.startForegroundService(Intent(c, IslandService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, IslandService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var pill: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var cutout = Rect()
    private var animator: ValueAnimator? = null
    private var expanded = false

    private val dp get() = resources.displayMetrics.density

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addOverlay()
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("lala", getString(R.string.lala_channel), NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "lala")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.lala_running))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        val container = FrameLayout(this)
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            gravity = Gravity.CENTER_HORIZONTAL or Gravity.BOTTOM
            setPadding((16 * dp).toInt(), 0, (16 * dp).toInt(), (9 * dp).toInt())
            alpha = 0f
            background = GradientDrawable().apply {
                setColor(Color.BLACK)
                cornerRadius = 100 * dp
            }
        }
        container.addView(
            tv,
            FrameLayout.LayoutParams(0, 0, Gravity.TOP or Gravity.CENTER_HORIZONTAL)
        )

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (140 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        try {
            wm.addView(container, lp)
        } catch (_: Throwable) {
            stopSelf()
            return
        }
        root = container
        pill = tv

        container.post {
            val cut = container.rootWindowInsets?.displayCutout?.boundingRectTop
            if (cut != null) cutout = Rect(cut)
            resize(idleW(), idleH())
            tv.alpha = 1f
        }
    }

    private fun hasCutout() = !cutout.isEmpty

    private fun idleW() = if (hasCutout()) cutout.width() + (10 * dp).toInt() else 0
    private fun idleH() = if (hasCutout()) cutout.bottom + (4 * dp).toInt() else 0
    private fun openW() = (resources.displayMetrics.widthPixels * 0.82f).toInt()
    private fun openH() = (if (hasCutout()) cutout.bottom else (12 * dp).toInt()) + (38 * dp).toInt()

    private fun resize(w: Int, h: Int) {
        val v = pill ?: return
        val p = v.layoutParams as FrameLayout.LayoutParams
        p.width = w
        p.height = h
        p.topMargin = if (hasCutout()) 0 else (8 * dp).toInt()
        v.layoutParams = p
    }

    private fun animateTo(w: Int, h: Int, textAlpha: Float) {
        val v = pill ?: return
        val startW = v.layoutParams.width
        val startH = v.layoutParams.height
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 320
            addUpdateListener {
                val f = it.animatedFraction
                resize((startW + (w - startW) * f).toInt(), (startH + (h - startH) * f).toInt())
                v.setTextColor(Color.argb((255 * (if (textAlpha > 0f) f else 1f - f)).toInt(), 255, 255, 255))
            }
            start()
        }
    }

    /** Показать уведомление в острове. */
    fun pop(text: String) {
        handler.post {
            val v = pill ?: return@post
            v.text = text
            handler.removeCallbacksAndMessages(null)
            if (!expanded) {
                expanded = true
                animateTo(openW(), openH(), 1f)
            }
            handler.postDelayed({
                expanded = false
                animateTo(idleW(), idleH(), 0f)
            }, 3200)
        }
    }

    override fun onDestroy() {
        instance = null
        handler.removeCallbacksAndMessages(null)
        animator?.cancel()
        try {
            root?.let { wm.removeView(it) }
        } catch (_: Throwable) {
        }
        root = null
        super.onDestroy()
    }
}
