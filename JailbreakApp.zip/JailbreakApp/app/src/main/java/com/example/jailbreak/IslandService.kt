package com.example.jailbreak

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.TextPaint
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

private enum class Mode { IDLE, TEXT, MEDIA, CALL }

/** Сама «таблетка» острова: рисует фон и содержимое для каждого режима. */
private class IslandView(ctx: Context) : View(ctx) {
    var mode = Mode.IDLE
    var text = ""
    var contentAlpha = 1f
    var phase = 0f
    var callStart = 0L
    var cutW = 0f
    var centerY = 0f

    private val d = resources.displayMetrics.density
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 12 * d
        textAlign = Paint.Align.CENTER
    }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 14 * d
        textAlign = Paint.Align.CENTER
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 11 * d
        textAlign = Paint.Align.CENTER
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val rad = min(w, h) / 2f
        c.drawRoundRect(0f, 0f, w, h, rad, rad, bg)

        val a = (255 * contentAlpha).toInt().coerceIn(0, 255)
        val lx = (w - cutW) / 4f // центр левой «ушной» области рядом с камерой
        val rx = w - lx
        val cy = if (centerY > 0f) centerY else h / 2f

        when (mode) {
            Mode.TEXT -> {
                tp.color = Color.argb(a, 255, 255, 255)
                val s = TextUtils.ellipsize(text, tp, w - 28 * d, TextUtils.TruncateAt.END).toString()
                c.drawText(s, w / 2f, h - 8 * d, tp)
            }

            Mode.MEDIA -> {
                glyph.color = Color.argb(a, 120, 200, 255)
                c.drawText("♫", lx, cy + 5 * d, glyph)
                bar.color = Color.argb(a, 120, 200, 255)
                for (i in 0 until 3) {
                    val hh = (4f + 9f * abs(sin(phase + i * 1.7f))) * d
                    val x = rx + (i - 1) * 5.5f * d
                    c.drawRoundRect(x - 1.5f * d, cy - hh / 2f, x + 1.5f * d, cy + hh / 2f, 1.5f * d, 1.5f * d, bar)
                }
            }

            Mode.CALL -> {
                glyph.color = Color.argb(a, 52, 199, 89)
                c.drawText("✆", lx, cy + 5 * d, glyph)
                val sec = ((System.currentTimeMillis() - callStart) / 1000).coerceAtLeast(0)
                small.color = Color.argb(a, 255, 255, 255)
                c.drawText(String.format("%d:%02d", sec / 60, sec % 60), rx, cy + 4 * d, small)
            }

            Mode.IDLE -> Unit
        }
    }
}

/**
 * lala 1.2: остров вокруг камеры.
 * Показывает уведомления, музыку (с эквалайзером), звонки (с таймером),
 * подключение зарядки и низкий заряд батареи.
 */
class IslandService : Service() {

    companion object {
        @Volatile
        var instance: IslandService? = null

        fun start(c: Context) {
            c.startForegroundService(Intent(c, IslandService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, IslandService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private var view: IslandView? = null
    private val handler = Handler(Looper.getMainLooper())
    private var cutout = Rect()
    private var animator: ValueAnimator? = null

    private var curMode = Mode.IDLE
    private var curText = ""
    private var transientText: String? = null
    private var lastMediaKey = ""
    private var ticking = false

    private val dp get() = resources.displayMetrics.density
    private val screenW get() = resources.displayMetrics.widthPixels
    private val lc by lazy { LocaleHelper.wrap(this) }

    private val endTransient = Runnable {
        transientText = null
        render()
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!ticking) return
            view?.let {
                it.phase += 0.35f
                it.invalidate()
            }
            handler.postDelayed(this, 60)
        }
    }

    private val power = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!Prefs.get(this@IslandService, Prefs.K_L_CHARGE, true)) return
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED ->
                    showTransient("⚡ " + lc.getString(R.string.lala_charging) + " · " + battery() + "%", 2800)

                Intent.ACTION_BATTERY_LOW ->
                    showTransient("⚠ " + lc.getString(R.string.lala_battery_low) + " · " + battery() + "%", 3500)
            }
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addOverlay()

        Live.onChange = { handler.post { onLive() } }

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_BATTERY_LOW)
        }
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                registerReceiver(power, f, Context.RECEIVER_NOT_EXPORTED)
            } else {
                registerReceiver(power, f)
            }
        } catch (_: Throwable) {
        }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("lala", getString(R.string.lala_channel), NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "lala")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.lala_running))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        val container = FrameLayout(this)
        val v = IslandView(this)
        container.addView(v, FrameLayout.LayoutParams(0, 0, Gravity.TOP or Gravity.START))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            (110 * dp).toInt(),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP
            layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        }

        try {
            wm.addView(container, lp)
        } catch (_: Throwable) {
            stopSelf()
            return
        }
        root = container
        view = v

        container.post {
            val cut = container.rootWindowInsets?.displayCutout?.boundingRectTop
            if (cut != null) cutout = Rect(cut)
            resize(idleW(), idleH())
            onLive()
        }
    }

    // ───────────── размеры ─────────────

    private fun hasCutout() = !cutout.isEmpty

    // Покой: вытянутая капсула, шире выреза, но невысокая
    private fun idleW() =
        if (hasCutout()) max((cutout.width() * 2.4f).toInt(), cutout.width() + (36 * dp).toInt()) else 0

    private fun idleH() = if (hasCutout()) cutout.bottom + (2 * dp).toInt() else 0

    // Компактный «живой» режим (музыка, звонок): по бокам от камеры появляются значки
    private fun compactW() =
        if (hasCutout()) cutout.width() + (96 * dp).toInt() else (130 * dp).toInt()

    private fun compactH() = if (hasCutout()) idleH() else (30 * dp).toInt()

    // Раскрыт: широкий, но низкий
    private fun openW() = (screenW * 0.68f).toInt()

    private fun openH() = (if (hasCutout()) cutout.bottom else (12 * dp).toInt()) + (22 * dp).toInt()

    private fun centerX() = if (hasCutout()) cutout.exactCenterX() else screenW / 2f

    private fun resize(w: Int, h: Int) {
        val v = view ?: return
        val p = v.layoutParams as FrameLayout.LayoutParams
        p.width = w
        p.height = h
        p.gravity = Gravity.TOP or Gravity.START
        val margin = (6 * dp).toInt()
        val maxLeft = max(margin, screenW - w - margin)
        p.leftMargin = (centerX() - w / 2f).toInt().coerceIn(margin, maxLeft)
        p.topMargin = if (hasCutout()) 0 else (8 * dp).toInt()
        v.cutW = if (hasCutout()) cutout.width().toFloat() else 0f
        v.centerY = if (hasCutout()) cutout.exactCenterY() else h / 2f
        v.layoutParams = p
    }

    // ───────────── логика состояний ─────────────

    private fun battery(): Int {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = b?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = b?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        return if (level >= 0) level * 100 / scale else 0
    }

    /** Обновилась музыка или звонок. */
    private fun onLive() {
        val m = Live.media
        if (m != null) {
            val key = m.title + "|" + m.artist
            if (key != lastMediaKey && m.title.isNotBlank()) {
                lastMediaKey = key
                val line = listOf(m.title, m.artist).filter { it.isNotBlank() }.joinToString(" · ")
                showTransient("♫ $line", 2800)
                return
            }
        }
        render()
    }

    private fun showTransient(text: String, ms: Long) {
        transientText = text
        handler.removeCallbacks(endTransient)
        handler.postDelayed(endTransient, ms)
        render()
    }

    private fun render() {
        val call = Live.call
        val t = transientText
        val target: Mode
        val text: String
        when {
            t != null -> { target = Mode.TEXT; text = t }
            call != null && call.ringing -> {
                target = Mode.TEXT
                text = "✆ " + lc.getString(R.string.lala_incoming) +
                    (if (call.name.isNotBlank()) " · ${call.name}" else "")
            }
            call != null -> { target = Mode.CALL; text = "" }
            Live.media != null -> { target = Mode.MEDIA; text = "" }
            else -> { target = Mode.IDLE; text = "" }
        }

        view?.callStart = call?.startMs ?: 0L
        if (target == curMode && text == curText) return
        go(target, text)
    }

    private fun setTicking(want: Boolean) {
        if (want && !ticking) {
            ticking = true
            handler.post(tick)
        } else if (!want && ticking) {
            ticking = false
            handler.removeCallbacks(tick)
        }
    }

    private fun go(mode: Mode, text: String) {
        val v = view ?: return
        curMode = mode
        curText = text

        val tw: Int
        val th: Int
        when (mode) {
            Mode.IDLE -> { tw = idleW(); th = idleH() }
            Mode.TEXT -> { tw = openW(); th = openH() }
            else -> { tw = compactW(); th = compactH() }
        }
        if (mode != Mode.IDLE) {
            v.mode = mode
            v.text = text
        }
        setTicking(mode == Mode.MEDIA || mode == Mode.CALL)

        val startW = v.layoutParams.width
        val startH = v.layoutParams.height
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            addUpdateListener {
                val f = it.animatedFraction
                resize((startW + (tw - startW) * f).toInt(), (startH + (th - startH) * f).toInt())
                v.contentAlpha = if (mode == Mode.IDLE) 1f - f else f
                v.invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (curMode == Mode.IDLE) v.mode = Mode.IDLE
                }
            })
            start()
        }
    }

    /** Показать произвольный текст в острове (например, тест). */
    fun pop(text: String) {
        handler.post { showTransient(text, 3000) }
    }

    override fun onDestroy() {
        instance = null
        Live.onChange = null
        try {
            unregisterReceiver(power)
        } catch (_: Throwable) {
        }
        setTicking(false)
        handler.removeCallbacksAndMessages(null)
        animator?.cancel()
        try {
            root?.let { wm.removeView(it) }
        } catch (_: Throwable) {
        }
        root = null
        view = null
        super.onDestroy()
    }
}
