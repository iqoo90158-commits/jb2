package com.example.jailbreak

import android.content.Context
import java.util.Locale

object LocaleHelper {
    fun wrap(base: Context): Context {
        val locale = Locale(Prefs.lang(base))
        Locale.setDefault(locale)
        val config = base.resources.configuration
        config.setLocale(locale)
        return base.createConfigurationContext(config)
    }
}
