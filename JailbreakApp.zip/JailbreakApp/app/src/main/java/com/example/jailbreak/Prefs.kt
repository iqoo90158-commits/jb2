package com.example.jailbreak

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.service.quicksettings.TileService

object Prefs {
    const val K_JB = "jailbroken"
    const val K_LANG = "lang"
    const val K_LALA = "tweak_lala"
    const val K_GRAV = "tweak_gravitation"
    const val K_LITE = "tweak_lite"
    const val K_GRAV_ON = "gravity_on"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("jb", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: Boolean = false) = sp(c).getBoolean(key, def)
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun jailbroken(c: Context) = get(c, K_JB)
    fun gravityOn(c: Context) = get(c, K_GRAV_ON, true)

    fun lang(c: Context): String = sp(c).getString(K_LANG, "ru") ?: "ru"
    fun setLang(c: Context, l: String) = sp(c).edit().putString(K_LANG, l).apply()

    /** Закрывает доступ ко всем твикам. */
    fun removeJailbreak(c: Context) {
        sp(c).edit()
            .putBoolean(K_JB, false)
            .putBoolean(K_LALA, false)
            .putBoolean(K_GRAV, false)
            .putBoolean(K_LITE, false)
            .apply()
        IslandService.stop(c)
        refreshTile(c)
    }

    fun refreshTile(c: Context) {
        try {
            TileService.requestListeningState(c, ComponentName(c, GravityTileService::class.java))
        } catch (_: Throwable) {
        }
    }
}
