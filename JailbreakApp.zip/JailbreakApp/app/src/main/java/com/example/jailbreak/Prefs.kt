package com.example.jailbreak

import android.content.ComponentName
import android.content.Context
import android.content.SharedPreferences
import android.service.quicksettings.TileService

object Prefs {
    const val K_JB = "jailbroken"
    const val K_LANG = "lang"
    const val K_LALA = "tweak_lala"
    const val K_GRAV = "tweak_gravitation"
    const val K_LITE = "tweak_lite"
    const val K_AURA = "tweak_aurora"
    const val K_GRAV_ON = "gravity_on"
    const val K_TORCH = "tweak_torch"
    const val K_L_NOTIF = "lala_notif"
    const val K_L_MUSIC = "lala_music"
    const val K_L_CALL = "lala_call"
    const val K_L_CHARGE = "lala_charge"
    const val K_AURA_COLOR = "aura_color"
    const val K_AURA_WIDTH = "aura_width"
    const val K_AURA_ONLY = "aura_only"
    const val K_AURA_PKGS = "aura_pkgs"

    fun sp(c: Context): SharedPreferences =
        c.applicationContext.getSharedPreferences("jb", Context.MODE_PRIVATE)

    fun get(c: Context, key: String, def: Boolean = false) = sp(c).getBoolean(key, def)
    fun set(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun getInt(c: Context, key: String, def: Int = 0) = sp(c).getInt(key, def)
    fun setInt(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()

    fun getSet(c: Context, key: String): Set<String> = sp(c).getStringSet(key, null) ?: emptySet()
    fun setSet(c: Context, key: String, v: Set<String>) =
        sp(c).edit().putStringSet(key, v.toHashSet()).apply()

    fun jailbroken(c: Context) = get(c, K_JB)
    fun gravityOn(c: Context) = get(c, K_GRAV_ON, true)

    fun lang(c: Context): String = sp(c).getString(K_LANG, "ru") ?: "ru"
    fun setLang(c: Context, l: String) = sp(c).edit().putString(K_LANG, l).apply()

    /** Закрывает доступ ко всем твикам. */
    fun removeJailbreak(c: Context) {
        sp(c).edit()
            .putBoolean(K_JB, false)
            .putBoolean(K_LALA, false)
            .putBoolean(K_GRAV, false)
            .putBoolean(K_LITE, false)
            .putBoolean(K_AURA, false)
            .putBoolean(K_TORCH, false)
            .apply()
        IslandService.stop(c)
        TorchService.stop(c)
        refreshTile(c)
    }

    fun refreshTile(c: Context) {
        try {
            TileService.requestListeningState(c, ComponentName(c, GravityTileService::class.java))
        } catch (_: Throwable) {
        }
    }
}
