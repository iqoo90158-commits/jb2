package com.example.jailbreak

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast

/** Gravitation: полноценный рабочий стол с физикой иконок. */
open class GravityActivity : Activity() {

    protected open val lite = false
    private var gv: GravityView? = null

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val key = if (lite) Prefs.K_LITE else Prefs.K_GRAV
        if (!Prefs.jailbroken(this) || !Prefs.get(this, key)) {
            Toast.makeText(this, R.string.toast_enable_first, Toast.LENGTH_SHORT).show()
            // Если этот рабочий стол был выбран главным, не оставляем пустой экран
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }
        val v = GravityView(this, lite)
        gv = v
        setContentView(v)
    }

    override fun onResume() {
        super.onResume()
        gv?.reloadIfChanged()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // нажали «Домой» — вернуться на первую страницу
        gv?.goHome()
    }

    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // это рабочий стол: «Назад» ничего не закрывает
    }
}

/** Gravitation Lite: спокойный параллакс без столкновений. */
class GravityLiteActivity : GravityActivity() {
    override val lite = true
}
