package com.example.jailbreak

import android.app.Activity
import android.content.Context
import android.os.Bundle
import android.widget.Toast

/** Gravitation: физический рабочий стол (иконки падают и сталкиваются). */
open class GravityActivity : Activity() {

    protected open val lite = false

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val key = if (lite) Prefs.K_LITE else Prefs.K_GRAV
        if (!Prefs.jailbroken(this) || !Prefs.get(this, key)) {
            Toast.makeText(this, R.string.toast_enable_first, Toast.LENGTH_SHORT).show()
            finish()
            return
        }
        setContentView(GravityView(this, lite))
    }
}

/** Gravitation Lite: спокойный параллакс без столкновений. */
class GravityLiteActivity : GravityActivity() {
    override val lite = true
}
