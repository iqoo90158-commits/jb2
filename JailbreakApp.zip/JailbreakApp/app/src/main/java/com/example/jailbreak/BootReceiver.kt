package com.example.jailbreak

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

/**
 * После перезагрузки или обновления приложения возвращает включённые службы.
 * Иначе переключатель в приложении горит, а твик молчит.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(c: Context, i: Intent?) {
        val action = i?.action ?: return
        if (action != Intent.ACTION_BOOT_COMPLETED &&
            action != Intent.ACTION_MY_PACKAGE_REPLACED &&
            action != "android.intent.action.QUICKBOOT_POWERON"
        ) return

        if (!Prefs.jailbroken(c)) return
        if (!Settings.canDrawOverlays(c)) return

        if (Prefs.get(c, Prefs.K_TORCH)) TorchService.start(c)
        if (Prefs.get(c, Prefs.K_NIGHT)) NightService.start(c)
    }
}
