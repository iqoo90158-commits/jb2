package com.example.jailbreak

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowInsets
import android.widget.Toast
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Рабочий стол 1.1: все приложения, страницы, док.
 *
 *  - Gravitation (lite = false): иконки падают, скользят и сталкиваются при наклоне.
 *    Удержание иконки — перетаскивание. Выключили гравитацию — иконки сами встают в сетку.
 *  - Gravitation Lite (lite = true): иконки остаются в сетке и «плывут» на разной глубине
 *    вслед за наклоном телефона (параллакс), с мягкими тенями.
 *
 * Общее: свайп влево/вправо — страницы, тап — запуск, тряска или двойной тап по пустому месту —
 * включить/выключить эффект.
 */
class GravityView(context: Context, private val lite: Boolean) : View(context), SensorEventListener {

    private class Body(
        val cn: ComponentName,
        val label: String,
        val icon: Bitmap,
        val depth: Float,
        val canRemove: Boolean
    ) {
        var page = 0
        var hx = 0f
        var hy = 0f
        var x = 0f
        var y = 0f
        var vx = 0f
        var vy = 0f
    }

    private val d = resources.displayMetrics.density
    private val iconPx = (56 * d).toInt()
    private val r = iconPx / 2f
    private val cols = 4

    private var bodies: List<Body> = emptyList()
    private var dock: List<Body> = emptyList()
    private val cur = ArrayList<Body>()

    private var pages = 1
    private var page = 0
    private var pageF = 0f

    // раскладка
    private var topInset = 0
    private var botInset = 0
    private var areaTop = 0f
    private var areaBottom = 0f
    private var dockTop = 0f
    private var dockBottom = 0f
    private var dotsY = 0f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11 * d
        textAlign = Paint.Align.CENTER
        setShadowLayer(3 * d, 0f, 1f, Color.BLACK)
    }
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        shader = RadialGradient(
            0f, 0f, r,
            intArrayOf(Color.argb(110, 0, 0, 0), Color.argb(0, 0, 0, 0)),
            floatArrayOf(0.5f, 1f),
            Shader.TileMode.CLAMP
        )
    }
    private val dockPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(64, 255, 255, 255) }
    private val dockStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.argb(96, 255, 255, 255)
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dockRect = RectF()

    // сенсоры
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private var gx = 0f
    private var gy = 9.8f
    private var hasBase = false
    private var baseX = 0f
    private var baseY = 0f
    private var tiltX = 0f
    private var tiltY = 0f
    private var lastShake = 0L
    private var gravityOn = Prefs.gravityOn(context)

    private var lastNs = 0L
    private var loading = false
    private var loadedSig = ""

    // касания
    private val slop = ViewConfiguration.get(context).scaledTouchSlop.toFloat()
    private var vt: VelocityTracker? = null
    private var touched: Body? = null
    private var moved = false
    private var swiping = false
    private var grabbed = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0L
    private var lastTap = 0L

    private val longPress = Runnable {
        val b = touched
        if (b != null && !moved && !swiping && menu == null) {
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            if (!lite && b.page >= 0) {
                // можно тащить; если отпустить на месте — откроется меню
                grabbed = true
            } else {
                openMenu(b)
                menuJustOpened = true
            }
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.K_GRAV_ON) gravityOn = Prefs.gravityOn(context)
    }

    // ───────────── жизненный цикл ─────────────

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        Prefs.sp(context).registerOnSharedPreferenceChangeListener(prefListener)
        gravityOn = Prefs.gravityOn(context)
        hasBase = false
        lastNs = 0L
        requestApplyInsets()
    }

    override fun onDetachedFromWindow() {
        sm.unregisterListener(this)
        Prefs.sp(context).unregisterOnSharedPreferenceChangeListener(prefListener)
        removeCallbacks(longPress)
        super.onDetachedFromWindow()
    }

    @Suppress("DEPRECATION")
    override fun onApplyWindowInsets(insets: WindowInsets): WindowInsets {
        topInset = insets.systemWindowInsetTop
        botInset = insets.systemWindowInsetBottom
        relayout()
        return insets
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        relayout()
        if (bodies.isEmpty()) loadAsync()
    }

    fun reloadIfChanged() = loadAsync()

    fun goHome() = setPage(0)

    // ───────────── загрузка приложений ─────────────

    private fun loadAsync() {
        if (loading) return
        loading = true
        Thread {
            try {
                val pm = context.packageManager
                val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                val infos = pm.queryIntentActivities(q, 0)
                val sig = infos.size.toString() + ":" +
                    infos.sumOf { it.activityInfo.packageName.hashCode().toLong() }
                if (sig == loadedSig) return@Thread

                // Док: телефон, сообщения, браузер, камера (что назначено по умолчанию)
                val dockIntents = listOf(
                    Intent(Intent.ACTION_DIAL),
                    Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")),
                    Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")),
                    Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                )
                val dockList = ArrayList<Body>()
                val dockPkgs = HashSet<String>()
                for (intent in dockIntents) {
                    val pkg = pm.resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY)
                        ?.activityInfo?.packageName ?: continue
                    if (pkg == "android" || pkg in dockPkgs) continue
                    val cn = pm.getLaunchIntentForPackage(pkg)?.component ?: continue
                    try {
                        val bmp = pm.getApplicationIcon(pkg).toBitmap(iconPx, iconPx)
                        dockList += Body(cn, "", bmp, 1f, false).also { it.page = -1 }
                        dockPkgs += pkg
                    } catch (_: Throwable) {
                    }
                }

                val seen = HashSet<ComponentName>()
                val list = ArrayList<Body>()
                val sorted = infos
                    .filter { it.activityInfo.packageName !in dockPkgs }
                    .sortedBy { it.loadLabel(pm).toString().lowercase() }
                for ((i, ri) in sorted.withIndex()) {
                    val cn = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
                    if (!seen.add(cn)) continue
                    val bmp = try {
                        ri.loadIcon(pm).toBitmap(iconPx, iconPx)
                    } catch (_: Throwable) {
                        continue
                    }
                    val name = ri.loadLabel(pm).toString()
                    val label = if (name.length > 11) name.take(10) + "…" else name
                    val ai = ri.activityInfo.applicationInfo
                    val isSys = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0 &&
                        (ai.flags and ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) == 0
                    val removable = !isSys && cn.packageName != context.packageName
                    list += Body(cn, label, bmp, 0.5f + (i * 37 % 10) / 10f, removable)
                }

                post {
                    bodies = list
                    dock = dockList
                    loadedSig = sig
                    relayout()
                }
            } finally {
                loading = false
            }
        }.start()
    }

    // ───────────── раскладка ─────────────

    private fun relayout() {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return

        val topPad = max(topInset.toFloat(), 24 * d) + 12 * d
        val botPad = max(botInset.toFloat(), 8 * d)
        val dockH = if (dock.isEmpty()) 0f else 84 * d

        dockBottom = h - botPad - 8 * d
        dockTop = dockBottom - dockH
        dotsY = (if (dock.isEmpty()) dockBottom else dockTop) - 14 * d
        areaTop = topPad
        areaBottom = dotsY - 16 * d

        val rows = ((areaBottom - areaTop) / (88 * d)).toInt().coerceAtLeast(1)
        val cellH = (areaBottom - areaTop) / rows
        val cellW = w / cols
        val perPage = cols * rows

        pages = max(1, ceil(bodies.size / perPage.toDouble()).toInt())
        page = page.coerceIn(0, pages - 1)
        pageF = page.toFloat()

        bodies.forEachIndexed { i, b ->
            b.page = i / perPage
            val idx = i % perPage
            b.hx = cellW * (idx % cols + 0.5f)
            b.hy = areaTop + cellH * (idx / cols + 0.45f)
            b.x = b.hx; b.y = b.hy; b.vx = 0f; b.vy = 0f
        }

        val margin = 28 * d
        dock.forEachIndexed { i, b ->
            b.hx = margin + (w - 2 * margin) / dock.size * (i + 0.5f)
            b.hy = dockTop + dockH / 2f
            b.x = b.hx; b.y = b.hy
        }
        rebuildCur()
    }

    private fun rebuildCur() {
        cur.clear()
        for (b in bodies) if (b.page == page) cur.add(b)
    }

    private fun setPage(p: Int) {
        page = p.coerceIn(0, pages - 1)
        rebuildCur()
    }

    // ───────────── физика ─────────────

    private fun step(dt: Float) {
        if (menu != null) return // пока открыто меню, всё замирает
        val w = width.toFloat()
        if (!swiping) pageF += (page - pageF) * min(1f, 14f * dt)
        if (lite) stepLite(dt) else stepPhysics(dt, w)
    }

    private fun stepLite(dt: Float) {
        val k = min(1f, 10f * dt)
        val nx = if (gravityOn) tiltX else 0f
        val ny = if (gravityOn) tiltY else 0f
        val amp = 30 * d
        for (b in bodies) {
            val tx = b.hx - nx * amp * b.depth
            val ty = b.hy - ny * amp * b.depth
            b.x += (tx - b.x) * k
            b.y += (ty - b.y) * k
        }
    }

    private fun stepPhysics(dt: Float, w: Float) {
        val floor = areaBottom - r - 14 * d
        val ceil = areaTop + r * 0.3f
        val rest = 15 * d

        if (!gravityOn) {
            // гравитация выключена: иконки пружиной возвращаются в сетку
            for (b in bodies) {
                if (b === touched && grabbed) continue
                b.vx += ((b.hx - b.x) * 90f - b.vx * 16f) * dt
                b.vy += ((b.hy - b.y) * 90f - b.vy * 16f) * dt
                b.x += b.vx * dt
                b.y += b.vy * dt
            }
            return
        }

        val scale = 110f * d
        val ax = gx * scale
        val ay = gy * scale
        for (b in cur) {
            if (b === touched && grabbed) continue
            b.vx += ax * dt
            b.vy += ay * dt
            val f = (1f - 0.35f * dt).coerceAtLeast(0f)
            b.vx *= f
            b.vy *= f
            b.x += b.vx * dt
            b.y += b.vy * dt

            if (b.x < r) { b.x = r; b.vx = if (-b.vx < rest) 0f else -b.vx * 0.5f }
            if (b.x > w - r) { b.x = w - r; b.vx = if (b.vx < rest) 0f else -b.vx * 0.5f }
            if (b.y < ceil) { b.y = ceil; b.vy = if (-b.vy < rest) 0f else -b.vy * 0.5f }
            if (b.y > floor) { b.y = floor; b.vy = if (b.vy < rest) 0f else -b.vy * 0.5f }
        }
        repeat(2) { collide() }
    }

    private fun collide() {
        val minD = 2f * r * 0.95f
        for (i in cur.indices) {
            for (j in i + 1 until cur.size) {
                val a = cur[i]
                val b = cur[j]
                val dx = b.x - a.x
                val dy = b.y - a.y
                val dist2 = dx * dx + dy * dy
                if (dist2 >= minD * minD || dist2 < 0.0001f) continue

                val dist = sqrt(dist2)
                val nx = dx / dist
                val ny = dy / dist
                val overlap = minD - dist
                val aFixed = a === touched && grabbed
                val bFixed = b === touched && grabbed

                when {
                    !aFixed && !bFixed -> {
                        a.x -= nx * overlap / 2; a.y -= ny * overlap / 2
                        b.x += nx * overlap / 2; b.y += ny * overlap / 2
                    }
                    aFixed -> { b.x += nx * overlap; b.y += ny * overlap }
                    else -> { a.x -= nx * overlap; a.y -= ny * overlap }
                }

                val vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny
                if (vn < 0) {
                    val imp = -(1f + 0.6f) * vn / 2f
                    if (!aFixed) { a.vx -= imp * nx; a.vy -= imp * ny }
                    if (!bFixed) { b.vx += imp * nx; b.vy += imp * ny }
                }
            }
        }
    }

    // ───────────── отрисовка ─────────────

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.033f)
        lastNs = now
        val w = width.toFloat()
        if (w > 0f) step(dt)

        for (b in bodies) {
            val off = (b.page - pageF) * w
            if (off <= -w || off >= w) continue
            drawBody(canvas, b, b.x + off, b.y, true)
        }

        if (dock.isNotEmpty()) {
            dockRect.set(16 * d, dockTop, w - 16 * d, dockBottom)
            canvas.drawRoundRect(dockRect, 30 * d, 30 * d, dockPaint)
            canvas.drawRoundRect(dockRect, 30 * d, 30 * d, dockStroke)
            for (b in dock) drawBody(canvas, b, b.x, b.y, false)
        }

        if (pages > 1) {
            val gap = 14 * d
            val startX = w / 2f - gap * (pages - 1) / 2f
            for (i in 0 until pages) {
                val active = 1f - min(1f, abs(i - pageF))
                dotPaint.color = Color.argb((90 + 165 * active).toInt(), 255, 255, 255)
                canvas.drawCircle(startX + gap * i, dotsY, (3f + 1.5f * active) * d, dotPaint)
            }
        }
        drawMenu(canvas, w)
        postInvalidateOnAnimation()
    }

    private fun drawBody(c: Canvas, b: Body, cx: Float, cy: Float, label: Boolean) {
        if (lite && label) {
            c.save()
            c.translate(cx + tiltX * 8 * d, cy + r * 0.5f + 6 * d + tiltY * 8 * d)
            c.drawCircle(0f, 0f, r, shadowPaint)
            c.restore()
        }
        c.drawBitmap(b.icon, cx - r, cy - r, paint)
        if (label) c.drawText(b.label, cx, cy + r + 13 * d, textPaint)
    }

    // ───────────── ввод ─────────────

    private fun hit(x: Float, y: Float): Body? {
        for (b in dock) if (hypot(b.x - x, b.y - y) <= r * 1.2f) return b
        for (i in cur.indices.reversed()) {
            val b = cur[i]
            if (hypot(b.x - x, b.y - y) <= r * 1.15f) return b
        }
        return null
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (menu != null) return menuTouch(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                vt?.recycle()
                vt = VelocityTracker.obtain().also { it.addMovement(e) }
                downX = e.x; downY = e.y
                lastX = e.x; lastY = e.y; lastT = e.eventTime
                moved = false; swiping = false; grabbed = false
                touched = hit(e.x, e.y)
                postDelayed(longPress, 260)
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                vt?.addMovement(e)
                val dx = e.x - downX
                val dy = e.y - downY
                if (!moved && hypot(dx, dy) > slop) {
                    moved = true
                    if (!grabbed) removeCallbacks(longPress)
                }
                val b = touched
                if (grabbed && b != null) {
                    val sec = (e.eventTime - lastT) / 1000f
                    if (sec > 0f) {
                        b.vx = ((e.x - lastX) / sec).coerceIn(-2500f * d, 2500f * d)
                        b.vy = ((e.y - lastY) / sec).coerceIn(-2500f * d, 2500f * d)
                    }
                    b.x = e.x.coerceIn(r, width - r)
                    b.y = e.y.coerceIn(areaTop, areaBottom)
                    lastX = e.x; lastY = e.y; lastT = e.eventTime
                } else if (swiping || (moved && abs(dx) > abs(dy) * 1.2f)) {
                    swiping = true
                    if (pages > 1) {
                        pageF = (page - dx / width).coerceIn(-0.25f, pages - 0.75f)
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                removeCallbacks(longPress)
                val dx = e.x - downX
                if (swiping) {
                    vt?.computeCurrentVelocity(1000)
                    val vx = vt?.xVelocity ?: 0f
                    var np = page
                    if (dx < -width * 0.2f || vx < -1200f) np = page + 1
                    else if (dx > width * 0.2f || vx > 1200f) np = page - 1
                    swiping = false
                    setPage(np)
                } else if (grabbed && !moved && e.actionMasked == MotionEvent.ACTION_UP) {
                    touched?.let {
                        openMenu(it)
                        menuJustOpened = false
                    }
                } else if (!grabbed && !moved && e.actionMasked == MotionEvent.ACTION_UP) {
                    val b = touched
                    if (b != null) launch(b) else emptyTap()
                }
                touched = null
                moved = false
                grabbed = false
                swiping = false
                vt?.recycle()
                vt = null
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun emptyTap() {
        val now = SystemClock.uptimeMillis()
        if (now - lastTap < 350) toggleGravity()
        lastTap = now
    }

    private fun launch(b: Body) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(b.cn)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            context.startActivity(i)
        } catch (_: Throwable) {
        }
    }

    private fun toggleGravity() {
        val on = !Prefs.gravityOn(context)
        Prefs.set(context, Prefs.K_GRAV_ON, on)
        gravityOn = on
        performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        Toast.makeText(
            context,
            if (on) R.string.toast_gravity_on else R.string.toast_gravity_off,
            Toast.LENGTH_SHORT
        ).show()
    }

    // ───────────── меню: удалить / о приложении ─────────────

    private class MenuItem(val label: String, val red: Boolean, val action: () -> Unit) {
        val rect = RectF()
    }

    private var menu: Body? = null
    private var menuJustOpened = false
    private val menuItems = ArrayList<MenuItem>()
    private val menuBox = RectF()
    private val scrimPaint = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val menuFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(240, 30, 32, 70) }
    private val menuLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = d
        color = Color.argb(70, 255, 255, 255)
    }
    private val itemText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 16 * d
        textAlign = Paint.Align.LEFT
    }

    private fun openMenu(b: Body) {
        menuItems.clear()
        val pkg = b.cn.packageName
        if (b.canRemove) {
            menuItems += MenuItem(context.getString(R.string.menu_uninstall), true) { uninstall(pkg) }
        }
        menuItems += MenuItem(context.getString(R.string.menu_info), false) { appInfo(pkg) }

        val w = 220 * d
        val rowH = 48 * d
        val h = rowH * menuItems.size + 8 * d
        val left = (b.x - w / 2f).coerceIn(12 * d, max(12 * d, width - w - 12 * d))
        var top = b.y - r - 14 * d - h
        if (top < 12 * d) top = b.y + r + 26 * d
        menuBox.set(left, top, left + w, top + h)
        menuItems.forEachIndexed { i, item ->
            item.rect.set(left, top + 4 * d + rowH * i, left + w, top + 4 * d + rowH * (i + 1))
        }
        menu = b
    }

    private fun menuTouch(e: MotionEvent): Boolean {
        // «хвост» того же касания, которым открыли меню, пропускаем
        if (menuJustOpened) {
            if (e.actionMasked == MotionEvent.ACTION_UP || e.actionMasked == MotionEvent.ACTION_CANCEL) {
                menuJustOpened = false
            }
            return true
        }
        if (e.actionMasked == MotionEvent.ACTION_UP) {
            val item = menuItems.firstOrNull { it.rect.contains(e.x, e.y) }
            menu = null
            item?.action?.invoke()
        } else if (e.actionMasked == MotionEvent.ACTION_CANCEL) {
            menu = null
        }
        return true
    }

    private fun drawMenu(c: Canvas, w: Float) {
        val m = menu ?: return
        c.drawRect(0f, 0f, w, height.toFloat(), scrimPaint)
        val off = if (m.page >= 0) (m.page - pageF) * w else 0f
        drawBody(c, m, m.x + off, m.y, m.page >= 0)

        c.drawRoundRect(menuBox, 22 * d, 22 * d, menuFill)
        c.drawRoundRect(menuBox, 22 * d, 22 * d, menuLine)
        menuItems.forEachIndexed { i, item ->
            itemText.color = if (item.red) Color.rgb(255, 98, 108) else Color.WHITE
            c.drawText(item.label, item.rect.left + 22 * d, item.rect.centerY() + 6 * d, itemText)
            if (i < menuItems.size - 1) {
                c.drawLine(item.rect.left + 16 * d, item.rect.bottom, item.rect.right - 16 * d, item.rect.bottom, menuLine)
            }
        }
    }

    private fun uninstall(pkg: String) {
        try {
            context.startActivity(
                Intent(Intent.ACTION_DELETE, Uri.parse("package:$pkg")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) {
        }
    }

    private fun appInfo(pkg: String) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Throwable) {
        }
    }

    // ───────────── датчик ─────────────

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]

        // экранные оси: x вправо, y вниз
        val sx = -x
        val sy = y
        if (!hasBase) {
            gx = sx; gy = sy
            baseX = sx; baseY = sy
            hasBase = true
        }
        gx += (sx - gx) * 0.2f
        gy += (sy - gy) * 0.2f

        // Lite: наклон относительно того, как телефон держат сейчас (медленно «забывается»)
        baseX += (gx - baseX) * 0.004f
        baseY += (gy - baseY) * 0.004f
        tiltX = ((gx - baseX) / 9.8f * 2.2f).coerceIn(-1f, 1f)
        tiltY = ((gy - baseY) / 9.8f * 2.2f).coerceIn(-1f, 1f)

        val mag = sqrt(x * x + y * y + z * z)
        val now = System.currentTimeMillis()
        if (mag > 26f && now - lastShake > 1000) {
            lastShake = now
            toggleGravity()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
