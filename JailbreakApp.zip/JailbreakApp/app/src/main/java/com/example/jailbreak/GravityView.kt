package com.example.jailbreak

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.widget.Toast
import androidx.core.graphics.drawable.toBitmap
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Физика иконок.
 *  - lite = false: падение, отскоки и столкновения (Gravitation).
 *  - lite = true: иконки в сетке мягко смещаются от наклона (Gravitation Lite).
 * Встряхивание включает и выключает гравитацию.
 */
class GravityView(context: Context, private val lite: Boolean) : View(context), SensorEventListener {

    private class Body(
        val pkg: String,
        val label: String,
        val icon: Bitmap,
        var x: Float,
        var y: Float,
        val hx: Float,
        val hy: Float,
        val depth: Float
    ) {
        var vx = 0f
        var vy = 0f
    }

    private val bodies = ArrayList<Body>()
    private val sm = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accel: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val d = resources.displayMetrics.density
    private val iconPx = (56 * d).toInt()
    private val r = iconPx / 2f

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 11 * d
        textAlign = Paint.Align.CENTER
        setShadowLayer(3 * d, 0f, 1f, Color.BLACK)
    }

    private var gx = 0f
    private var gy = 9.8f
    private var lastNs = 0L
    private var lastShake = 0L
    private var gravityOn = Prefs.gravityOn(context)

    private var touched: Body? = null
    private var moved = false
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var lastT = 0L

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.K_GRAV_ON) gravityOn = Prefs.gravityOn(context)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        accel?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        Prefs.sp(context).registerOnSharedPreferenceChangeListener(prefListener)
        gravityOn = Prefs.gravityOn(context)
        lastNs = 0L
    }

    override fun onDetachedFromWindow() {
        sm.unregisterListener(this)
        Prefs.sp(context).unregisterOnSharedPreferenceChangeListener(prefListener)
        super.onDetachedFromWindow()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (bodies.isEmpty() && w > 0 && h > 0) loadApps(w, h)
    }

    private fun loadApps(w: Int, h: Int) {
        val pm = context.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val cols = 4
        val cellW = w / cols.toFloat()
        val cellH = 88 * d
        val top = 90 * d
        val rows = ((h - top - 40 * d) / cellH).toInt().coerceAtLeast(1)
        val cap = if (lite) cols * rows else min(36, cols * 12)

        val apps = pm.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != context.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }
            .take(cap)

        apps.forEachIndexed { i, ri ->
            val bmp = try {
                ri.loadIcon(pm).toBitmap(iconPx, iconPx)
            } catch (_: Throwable) {
                return@forEachIndexed
            }
            val cx = cellW * (i % cols + 0.5f)
            val cy = top + cellH * (i / cols)
            val depth = 0.5f + (i * 37 % 10) / 10f
            bodies += Body(
                ri.activityInfo.packageName,
                ri.loadLabel(pm).toString().take(9),
                bmp, cx, cy, cx, cy, depth
            )
        }
    }

    // ---------- Физика ----------

    private fun step(dt: Float) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (lite) stepLite(dt) else stepPhysics(dt, w, h)
    }

    private fun stepLite(dt: Float) {
        val k = min(1f, 8f * dt)
        val nx = if (gravityOn) (gx / 9.8f).coerceIn(-1.2f, 1.2f) else 0f
        val ny = if (gravityOn) ((gy - 6f) / 9.8f).coerceIn(-1.2f, 1.2f) else 0f
        for (b in bodies) {
            val tx = b.hx + nx * 16 * d * b.depth
            val ty = b.hy + ny * 16 * d * b.depth
            b.x += (tx - b.x) * k
            b.y += (ty - b.y) * k
        }
    }

    private fun stepPhysics(dt: Float, w: Float, h: Float) {
        val scale = 110f * d
        val ax = if (gravityOn) gx * scale else 0f
        val ay = if (gravityOn) gy * scale else 0f
        val damp = if (gravityOn) 0.35f else 1.4f
        val floor = h - r - 24 * d
        val rest = 15 * d

        for (b in bodies) {
            if (b === touched && moved) continue
            b.vx += ax * dt
            b.vy += ay * dt
            val f = (1f - damp * dt).coerceAtLeast(0f)
            b.vx *= f
            b.vy *= f
            b.x += b.vx * dt
            b.y += b.vy * dt

            if (b.x < r) { b.x = r; b.vx = if (-b.vx < rest) 0f else -b.vx * 0.5f }
            if (b.x > w - r) { b.x = w - r; b.vx = if (b.vx < rest) 0f else -b.vx * 0.5f }
            if (b.y < r) { b.y = r; b.vy = if (-b.vy < rest) 0f else -b.vy * 0.5f }
            if (b.y > floor) { b.y = floor; b.vy = if (b.vy < rest) 0f else -b.vy * 0.5f }
        }

        repeat(2) { collide() }
    }

    private fun collide() {
        val minD = 2f * r * 0.95f
        for (i in bodies.indices) {
            for (j in i + 1 until bodies.size) {
                val a = bodies[i]
                val b = bodies[j]
                val dx = b.x - a.x
                val dy = b.y - a.y
                val dist2 = dx * dx + dy * dy
                if (dist2 >= minD * minD || dist2 < 0.0001f) continue

                val dist = sqrt(dist2)
                val nx = dx / dist
                val ny = dy / dist
                val overlap = minD - dist
                val aFixed = a === touched && moved
                val bFixed = b === touched && moved

                when {
                    !aFixed && !bFixed -> {
                        a.x -= nx * overlap / 2; a.y -= ny * overlap / 2
                        b.x += nx * overlap / 2; b.y += ny * overlap / 2
                    }
                    aFixed -> { b.x += nx * overlap; b.y += ny * overlap }
                    else -> { a.x -= nx * overlap; a.y -= ny * overlap }
                }

                val vn = (b.vx - a.vx) * nx + (b.vy - a.vy) * ny
                if (vn < 0) {
                    val imp = -(1f + 0.6f) * vn / 2f
                    if (!aFixed) { a.vx -= imp * nx; a.vy -= imp * ny }
                    if (!bFixed) { b.vx += imp * nx; b.vy += imp * ny }
                }
            }
        }
    }

    // ---------- Отрисовка ----------

    override fun onDraw(canvas: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else ((now - lastNs) / 1e9f).coerceIn(0.001f, 0.033f)
        lastNs = now
        if (width > 0) step(dt)

        for (b in bodies) {
            canvas.drawBitmap(b.icon, b.x - r, b.y - r, paint)
            canvas.drawText(b.label, b.x, b.y + r + 13 * d, textPaint)
        }
        postInvalidateOnAnimation()
    }

    // ---------- Ввод ----------

    private fun hit(x: Float, y: Float): Body? =
        bodies.lastOrNull { hypot(it.x - x, it.y - y) <= r * 1.15f }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.x; downY = e.y
                lastX = e.x; lastY = e.y; lastT = e.eventTime
                moved = false
                touched = hit(e.x, e.y)
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val b = touched ?: return true
                if (lite) return true
                if (!moved && hypot(e.x - downX, e.y - downY) > 12 * d) moved = true
                if (moved) {
                    val sec = (e.eventTime - lastT) / 1000f
                    if (sec > 0f) {
                        b.vx = ((e.x - lastX) / sec).coerceIn(-2500f * d, 2500f * d)
                        b.vy = ((e.y - lastY) / sec).coerceIn(-2500f * d, 2500f * d)
                    }
                    b.x = e.x
                    b.y = e.y
                    lastX = e.x; lastY = e.y; lastT = e.eventTime
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val b = touched
                if (b != null && !moved) launch(b)
                touched = null
                moved = false
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                touched = null
                moved = false
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    private fun launch(b: Body) {
        val i = context.packageManager.getLaunchIntentForPackage(b.pkg) ?: return
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(i)
    }

    // ---------- Датчик ----------

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]

        // экранные оси: x вправо, y вниз
        gx += (-x - gx) * 0.2f
        gy += (y - gy) * 0.2f

        val mag = sqrt(x * x + y * y + z * z)
        val now = System.currentTimeMillis()
        if (mag > 28f && now - lastShake > 1000) {
            lastShake = now
            val on = !Prefs.gravityOn(context)
            Prefs.set(context, Prefs.K_GRAV_ON, on)
            gravityOn = on
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            Toast.makeText(
                context,
                if (on) R.string.toast_gravity_on else R.string.toast_gravity_off,
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit
}
