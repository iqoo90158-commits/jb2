package com.example.jailbreak

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import java.util.Locale

object DeviceInfo {

    data class Info(
        val osName: String,
        val osVersion: String,
        val groups: List<List<Pair<Int, String>>>
    )

    private fun prop(key: String): String = try {
        Class.forName("android.os.SystemProperties")
            .getMethod("get", String::class.java)
            .invoke(null, key) as String
    } catch (_: Throwable) {
        ""
    }

    private fun gb(bytes: Long) = String.format(Locale.US, "%.1f GB", bytes / 1024.0 / 1024.0 / 1024.0)

    @Suppress("DEPRECATION")
    fun collect(ctx: Context): Info {
        val brand = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val title = if (Build.MODEL.startsWith(brand, true)) Build.MODEL else "$brand ${Build.MODEL}"

        val miVer = prop("ro.mi.os.version.incremental")
        val isHyper = prop("ro.mi.os.version.name").isNotEmpty() || miVer.isNotEmpty()
        val osName = if (isHyper) "Xiaomi HyperOS" else "Android"
        val osVersion = if (isHyper) {
            Regex("""\d+(\.\d+)+""").find(miVer)?.value ?: Build.VERSION.RELEASE
        } else {
            Build.VERSION.RELEASE
        }

        val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }

        val st = StatFs(Environment.getDataDirectory().path)
        val total = st.blockCountLong * st.blockSizeLong
        val free = st.availableBlocksLong * st.blockSizeLong

        val dm = ctx.resources.displayMetrics
        val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as android.view.WindowManager
        val hz = wm.defaultDisplay.refreshRate.toInt()

        val bat = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = bat?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = bat?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val pct = if (level >= 0) level * 100 / scale else -1

        val hw = buildString {
            append(Build.HARDWARE)
            if (Build.VERSION.SDK_INT >= 31 && Build.SOC_MODEL.isNotEmpty() && Build.SOC_MODEL != "unknown") {
                append(" · ").append(Build.SOC_MODEL)
            }
        }

        val groups = listOf(
            listOf(
                R.string.label_device to title,
                R.string.label_storage to "${gb(total - free)} / ${gb(total)}"
            ),
            listOf(
                R.string.label_system to "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                R.string.label_patch to (Build.VERSION.SECURITY_PATCH ?: "—")
            ),
            listOf(
                R.string.label_kernel to (System.getProperty("os.version") ?: "—"),
                R.string.label_hardware to hw,
                R.string.label_abi to (Build.SUPPORTED_ABIS.firstOrNull() ?: "—")
            ),
            listOf(
                R.string.label_ram to gb(mi.totalMem),
                R.string.label_screen to "${dm.widthPixels}×${dm.heightPixels} · ${dm.densityDpi} dpi · $hz Hz",
                R.string.label_battery to if (pct >= 0) "$pct%" else "—",
                R.string.label_build to Build.DISPLAY
            )
        )
        return Info(osName, osVersion, groups)
    }
}
