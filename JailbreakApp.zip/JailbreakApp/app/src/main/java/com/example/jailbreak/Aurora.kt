package com.example.jailbreak

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.SweepGradient
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import kotlin.math.PI
import kotlin.math.sin

/**
 * Aurora: по краю экрана пробегает светящаяся переливающаяся рамка,
 * когда приходит уведомление. Рисуется поверх любых приложений.
 *
 * Настраивается цвет (пресеты), толщина рамки и список приложений,
 * для которых рамка показывается.
 */
object Aurora {
    private val handler = Handler(Looper.getMainLooper())
    private var current: AuroraView? = null

    /** Пресеты цвета рамки: 0 — радуга, дальше однотонные. */
    private val presets: List<IntArray> = listOf(
        intArrayOf(
            0xFF4FC3F7.toInt(), 0xFFB388FF.toInt(), 0xFFFF80AB.toInt(),
            0xFFFFD180.toInt(), 0xFF4FC3F7.toInt()
        ),
        intArrayOf(0xFF3482FF.toInt(), 0xFF9CC8FF.toInt(), 0xFF3482FF.toInt()),
        intArrayOf(0xFFB388FF.toInt(), 0xFFE6D4FF.toInt(), 0xFFB388FF.toInt()),
        intArrayOf(0xFFFF80AB.toInt(), 0xFFFFC4D8.toInt(), 0xFFFF80AB.toInt()),
        intArrayOf(0xFF41D96B.toInt(), 0xFFB7F2C6.toInt(), 0xFF41D96B.toInt())
    )

    val presetCount: Int get() = presets.size

    /** Цвет-образец для кружка в настройках. */
    fun presetColor(index: Int): Int = presets[index.coerceIn(0, presets.lastIndex)][0]

    private fun presetColors(index: Int): IntArray = presets[index.coerceIn(0, presets.lastIndex)]

    /** 0 — тонкая, 1 — обычная, 2 — толстая. */
    private fun widthScale(index: Int): Float = when (index) {
        0 -> 0.6f
        2 -> 1.7f
        else -> 1f
    }

    /**
     * Показать рамку. [pkg] — пакет, от которого пришло уведомление:
     * если включён режим «только выбранные», остальные не показывают рамку.
     */
    fun flash(ctx: Context, pkg: String? = null) {
        val app = ctx.applicationContext
        if (pkg != null &&
            Prefs.get(app, Prefs.K_AURA_ONLY) &&
            pkg !in Prefs.getSet(app, Prefs.K_AURA_PKGS)
        ) return

        val colors = presetColors(Prefs.getInt(app, Prefs.K_AURA_COLOR))
        val scale = widthScale(Prefs.getInt(app, Prefs.K_AURA_WIDTH, 1))

        handler.post {
            if (!Settings.canDrawOverlays(app)) return@post
            remove(app)
            val wm = app.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = AuroraView(app, colors, scale)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            )
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            try {
                wm.addView(v, lp)
                current = v
                v.start { remove(app) }
            } catch (_: Throwable) {
            }
        }
    }

    private fun remove(app: Context) {
        val v = current ?: return
        current = null
        v.cancel()
        try {
            (app.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {
        }
    }
}

private class AuroraView(
    ctx: Context,
    private val colors: IntArray,
    private val scale: Float
) : View(ctx) {

    private val d = resources.displayMetrics.density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var radius = 40 * d
    private var rotation = 0f
    private var strength = 0f
    private var animator: ValueAnimator? = null

    fun start(onEnd: () -> Unit) {
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2800
            interpolator = LinearInterpolator()
            addUpdateListener {
                val t = it.animatedValue as Float
                rotation = 360f * t
                strength = sin(PI * t).toFloat()
                invalidate()
            }
            addListener(object : android.animation.AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: android.animation.Animator) = onEnd()
            })
            start()
        }
    }

    fun cancel() {
        animator?.removeAllListeners()
        animator?.cancel()
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        shader = SweepGradient(w / 2f, h / 2f, colors, null)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (Build.VERSION.SDK_INT >= 31) {
            val rc = rootWindowInsets?.getRoundedCorner(android.view.RoundedCorner.POSITION_TOP_LEFT)
            if (rc != null) radius = rc.radius.toFloat()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val s = shader ?: return
        matrix.setRotate(rotation, width / 2f, height / 2f)
        s.setLocalMatrix(matrix)
        paint.shader = s

        // Мягкое свечение: несколько штрихов разной толщины и прозрачности
        val layers = 4
        for (i in layers - 1 downTo 0) {
            val sw = (3f + i * 7f) * d * scale
            paint.strokeWidth = sw
            paint.alpha = (255 * strength * (if (i == 0) 1f else 0.28f / i)).toInt().coerceIn(0, 255)
            val inset = sw / 2f
            rect.set(inset, inset, width - inset, height - inset)
            canvas.drawRoundRect(rect, radius, radius, paint)
        }
    }
}
