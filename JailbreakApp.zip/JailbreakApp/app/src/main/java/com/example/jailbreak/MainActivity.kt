package com.example.jailbreak

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val HyperBlue = Color(0xFF3482FF)
private val HyperRed = Color(0xFFFF4D5A)
private val Dim = Color(0xB3FFFFFF)

class MainActivity : ComponentActivity() {

    private val resumeTick = mutableIntStateOf(0)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val transparent = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(transparent),
            navigationBarStyle = SystemBarStyle.dark(transparent)
        )
        setContent {
            HyperTheme {
                AppRoot(resumeTick.intValue, onLanguageChanged = { recreate() })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

// ───────────────────────── Тема: фон как в «О телефоне» HyperOS 3 ─────────────────────────

@Composable
fun HyperTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = HyperBlue,
            background = Color(0xFF0A1250),
            surface = Color(0xFF1B1E4B),
            onBackground = Color.White,
            onSurface = Color.White,
            onSurfaceVariant = Dim,
            surfaceVariant = Color(0x26FFFFFF)
        ),
        content = content
    )
}

/** Глубокий сине-фиолетовый градиент с медленно плывущими световыми пятнами. */
@Composable
fun HyperBackground(content: @Composable BoxScope.() -> Unit) {
    val tr = rememberInfiniteTransition(label = "bg")
    val p by tr.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "p"
    )
    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(
                        Color(0xFF0A1250),
                        Color(0xFF1D1C78),
                        Color(0xFF3B1F80),
                        Color(0xFF120E2E)
                    )
                )
            )
            .drawBehind {
                val w = size.width
                val h = size.height
                fun blob(c: Color, cx: Float, cy: Float, rad: Float) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(c, Color.Transparent),
                            center = Offset(cx, cy),
                            radius = rad
                        ),
                        radius = rad,
                        center = Offset(cx, cy)
                    )
                }
                blob(Color(0xCCB03CFF), w * (0.95f - 0.12f * p), h * (0.10f + 0.04f * p), w * 0.85f)
                blob(Color(0xAA2E6BFF), w * (0.05f + 0.10f * p), h * (0.38f - 0.05f * p), w * 0.9f)
                blob(Color(0x883A1E9A), w * (0.70f - 0.20f * p), h * 0.85f, w * 0.9f)
            }
    ) {
        CompositionLocalProvider(LocalContentColor provides Color.White) {
            content()
        }
    }
}

/** «Жидкое стекло»: полупрозрачная заливка, световой блик, переливающаяся кромка. */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    corner: Dp = 28.dp,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(corner)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(
                Brush.linearGradient(
                    listOf(Color(0x38FFFFFF), Color(0x14FFFFFF), Color(0x26FFFFFF))
                )
            )
            .drawBehind {
                // световой блик в левом верхнем углу
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x30FFFFFF), Color.Transparent),
                        center = Offset(size.width * 0.12f, 0f),
                        radius = size.width * 0.55f
                    ),
                    radius = size.width * 0.55f,
                    center = Offset(size.width * 0.12f, 0f)
                )
            }
            .border(
                1.dp,
                Brush.linearGradient(
                    listOf(Color(0x99FFFFFF), Color(0x14FFFFFF), Color(0x55FFFFFF))
                ),
                shape
            )
            .padding(horizontal = 20.dp, vertical = 10.dp),
        content = content
    )
}

@Composable
private fun GlassPill(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(Color(0x26FFFFFF))
            .border(1.dp, Color(0x40FFFFFF), CircleShape)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 10.dp)
    ) {
        Text(text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text,
        fontSize = 13.sp,
        color = Dim,
        modifier = Modifier.padding(start = 12.dp, top = 4.dp)
    )
}

@Composable
private fun Hairline() {
    Box(
        Modifier
            .fillMaxWidth()
            .height(1.dp)
            .background(Color(0x1FFFFFFF))
    )
}

// ───────────────────────── Навигация ─────────────────────────

@Composable
fun AppRoot(tick: Int, onLanguageChanged: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableIntStateOf(0) }
    var jb by remember { mutableStateOf(Prefs.jailbroken(ctx)) }

    BackHandler(screen == 1) { screen = 0 }

    HyperBackground {
        if (screen == 0) {
            HomeScreen(
                jb = jb,
                tick = tick,
                onJailbroken = { jb = true },
                onSettings = { screen = 1 }
            )
        } else {
            SettingsScreen(
                onBack = { screen = 0 },
                onLanguageChanged = onLanguageChanged,
                onRemoved = { jb = false; screen = 0 }
            )
        }
    }
}

// ───────────────────────── Главный экран ─────────────────────────

@Composable
fun HomeScreen(jb: Boolean, tick: Int, onJailbroken: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val info = remember(tick) { DeviceInfo.collect(ctx) }
    val scope = rememberCoroutineScope()

    var running by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(0) }
    val steps = listOf(R.string.step_1, R.string.step_2, R.string.step_3)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Верхняя строка
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.app_name),
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                color = Dim,
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            )
            GlassPill(stringResource(R.string.settings), onSettings)
        }

        // Большой заголовок ОС, как на экране «О телефоне»
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 28.dp, bottom = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                info.osName,
                style = TextStyle(
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF7FA8FF), Color(0xFFB69BFF), Color(0xFFD7A5FF))
                    ),
                    fontSize = 38.sp,
                    fontWeight = FontWeight.Bold
                ),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(info.osVersion, fontSize = 15.sp, color = Dim)
        }

        // Параметры устройства в стеклянных карточках
        info.groups.forEach { rows -> GroupCard(rows) }

        // Кнопка джейлбрейка
        Spacer(Modifier.height(4.dp))
        Button(
            onClick = {
                if (jb || running) return@Button
                scope.launch {
                    running = true
                    for (i in steps.indices) {
                        step = i
                        delay(900)
                    }
                    Prefs.set(ctx, Prefs.K_JB, true)
                    Prefs.refreshTile(ctx)
                    running = false
                    onJailbroken()
                }
            },
            enabled = !jb && !running,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = HyperBlue,
                contentColor = Color.White,
                disabledContainerColor = if (jb) Color(0xFF34C759) else HyperBlue.copy(alpha = 0.55f),
                disabledContentColor = Color.White
            )
        ) {
            Text(
                when {
                    running -> stringResource(steps[step])
                    jb -> stringResource(R.string.btn_done)
                    else -> stringResource(R.string.btn_jailbreak)
                },
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        if (running) {
            LinearProgressIndicator(
                progress = { (step + 1) / steps.size.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                color = HyperBlue,
                trackColor = Color(0x33FFFFFF)
            )
        }

        // Твики
        if (jb) {
            SectionLabel(stringResource(R.string.tweaks))
            LalaCard(tick)
            AuroraCard(tick)
            TorchCard()
            GravityCard(
                nameRes = R.string.tweak_grav_name,
                descRes = R.string.tweak_grav_desc,
                key = Prefs.K_GRAV,
                target = GravityActivity::class.java
            )
            GravityCard(
                nameRes = R.string.tweak_lite_name,
                descRes = R.string.tweak_lite_desc,
                key = Prefs.K_LITE,
                target = GravityLiteActivity::class.java
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun GroupCard(rows: List<Pair<Int, String>>) {
    GlassCard {
        rows.forEachIndexed { i, (label, value) ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Text(
                    stringResource(label),
                    fontSize = 16.sp,
                    modifier = Modifier.weight(0.45f)
                )
                Text(
                    value,
                    fontSize = 15.sp,
                    color = Dim,
                    textAlign = TextAlign.End,
                    modifier = Modifier.weight(0.55f)
                )
            }
            if (i < rows.lastIndex) Hairline()
        }
    }
}

// ───────────────────────── Карточки твиков ─────────────────────────

@Composable
private fun TweakHeader(nameRes: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.padding(top = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            stringResource(nameRes),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun openOverlaySettings(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
    )
}

/** Строки «нужно разрешение» для твиков с окном поверх всего и уведомлениями. */
@Composable
private fun PermissionRows(tick: Int) {
    val ctx = LocalContext.current
    val hasOverlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val hasNotifAccess = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    if (!hasOverlay) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(R.string.overlay_needed),
                fontSize = 13.sp,
                color = HyperRed,
                modifier = Modifier.weight(1f)
            )
            TextButton(onClick = { openOverlaySettings(ctx) }) {
                Text(stringResource(R.string.grant))
            }
        }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(if (hasNotifAccess) R.string.notif_access_on else R.string.notif_access),
            fontSize = 13.sp,
            modifier = Modifier.weight(1f)
        )
        if (!hasNotifAccess) {
            TextButton(onClick = {
                ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            }) { Text(stringResource(R.string.grant)) }
        }
    }
}

@Composable
private fun LalaCard(tick: Int) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, Prefs.K_LALA)) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    GlassCard {
        TweakHeader(R.string.tweak_lala_name, on) { want ->
            if (want) {
                if (!Settings.canDrawOverlays(ctx)) {
                    openOverlaySettings(ctx)
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    Prefs.set(ctx, Prefs.K_LALA, true)
                    IslandService.start(ctx)
                    Live.optionChanged(ctx)
                    on = true
                }
            } else {
                Prefs.set(ctx, Prefs.K_LALA, false)
                IslandService.stop(ctx)
                Live.optionChanged(ctx)
                on = false
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.tweak_lala_desc), fontSize = 14.sp, color = Dim)
        Spacer(Modifier.height(4.dp))
        PermissionRows(tick)
        if (on) {
            OptionRow(R.string.lala_opt_notif, Prefs.K_L_NOTIF)
            OptionRow(R.string.lala_opt_music, Prefs.K_L_MUSIC)
            OptionRow(R.string.lala_opt_call, Prefs.K_L_CALL)
            OptionRow(R.string.lala_opt_charge, Prefs.K_L_CHARGE)
            TextButton(onClick = {
                IslandService.instance?.pop("lala · " + ctx.getString(R.string.test_text))
            }) { Text(stringResource(R.string.test)) }
        }
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun AuroraCard(tick: Int) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, Prefs.K_AURA)) }
    var color by remember { mutableIntStateOf(Prefs.getInt(ctx, Prefs.K_AURA_COLOR)) }
    var width by remember { mutableIntStateOf(Prefs.getInt(ctx, Prefs.K_AURA_WIDTH, 1)) }
    var only by remember { mutableStateOf(Prefs.get(ctx, Prefs.K_AURA_ONLY)) }
    var pick by remember { mutableStateOf(false) }

    GlassCard {
        TweakHeader(R.string.tweak_aura_name, on) { want ->
            if (want && !Settings.canDrawOverlays(ctx)) {
                openOverlaySettings(ctx)
            } else {
                Prefs.set(ctx, Prefs.K_AURA, want)
                on = want
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.tweak_aura_desc), fontSize = 14.sp, color = Dim)
        Spacer(Modifier.height(4.dp))
        PermissionRows(tick)

        if (on) {
            Spacer(Modifier.height(12.dp))
            SectionLabel(stringResource(R.string.aura_color))
            Row(
                Modifier.padding(start = 12.dp, top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                for (i in 0 until Aurora.presetCount) {
                    Box(
                        Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color(Aurora.presetColor(i)))
                            .border(
                                width = if (i == color) 2.dp else 1.dp,
                                color = if (i == color) Color.White else Color(0x33FFFFFF),
                                shape = CircleShape
                            )
                            .clickable {
                                color = i
                                Prefs.setInt(ctx, Prefs.K_AURA_COLOR, i)
                            }
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            SectionLabel(stringResource(R.string.aura_width))
            Row(
                Modifier.padding(start = 12.dp, top = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Chip(stringResource(R.string.aura_thin), width == 0) {
                    width = 0
                    Prefs.setInt(ctx, Prefs.K_AURA_WIDTH, 0)
                }
                Chip(stringResource(R.string.aura_normal), width == 1) {
                    width = 1
                    Prefs.setInt(ctx, Prefs.K_AURA_WIDTH, 1)
                }
                Chip(stringResource(R.string.aura_thick), width == 2) {
                    width = 2
                    Prefs.setInt(ctx, Prefs.K_AURA_WIDTH, 2)
                }
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.aura_only_apps),
                    fontSize = 15.sp,
                    modifier = Modifier.weight(1f)
                )
                Switch(checked = only, onCheckedChange = {
                    only = it
                    Prefs.set(ctx, Prefs.K_AURA_ONLY, it)
                })
            }
            if (only) {
                TextButton(onClick = { pick = true }) {
                    Text(
                        stringResource(R.string.aura_pick_apps) +
                            " · " + Prefs.getSet(ctx, Prefs.K_AURA_PKGS).size
                    )
                }
            }

            Spacer(Modifier.height(4.dp))
            TextButton(onClick = { Aurora.flash(ctx) }) { Text(stringResource(R.string.test)) }
        }
        Spacer(Modifier.height(4.dp))
    }

    if (pick) {
        AuroraAppPicker(onDismiss = { pick = false })
    }
}

/** Небольшая капсула-переключатель. */
@Composable
private fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Color(0x593482FF) else Color(0x1AFFFFFF))
            .border(1.dp, if (selected) HyperBlue else Color(0x33FFFFFF), CircleShape)
            .clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 7.dp)
    ) {
        Text(text, fontSize = 13.sp)
    }
}

/** Выбор приложений, для которых показывать Aurora. */
@Composable
private fun AuroraAppPicker(onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var apps by remember { mutableStateOf<List<Pair<String, String>>?>(null) }
    var sel by remember { mutableStateOf(Prefs.getSet(ctx, Prefs.K_AURA_PKGS)) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = ctx.packageManager
            val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(q, 0)
                .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
                .distinctBy { it.first }
                .sortedBy { it.second.lowercase() }
        }
    }

    val list = apps
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B1E4B),
        title = { Text(stringResource(R.string.aura_pick_apps)) },
        text = {
            Column {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    placeholder = { Text(stringResource(R.string.aura_search)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                if (list == null) {
                    Box(Modifier.fillMaxWidth().height(120.dp), Alignment.Center) {
                        CircularProgressIndicator(color = HyperBlue)
                    }
                } else {
                    LazyColumn(Modifier.heightIn(max = 360.dp)) {
                        items(list.filter {
                            it.second.contains(query, true) || it.first.contains(query, true)
                        }) { (pkg, label) ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        sel = if (pkg in sel) sel - pkg else sel + pkg
                                    }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(label, fontSize = 15.sp, modifier = Modifier.weight(1f))
                                Switch(
                                    checked = pkg in sel,
                                    onCheckedChange = { want ->
                                        sel = if (want) sel + pkg else sel - pkg
                                    }
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                Prefs.setSet(ctx, Prefs.K_AURA_PKGS, sel)
                onDismiss()
            }) { Text(stringResource(R.string.done)) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel)) }
        }
    )
}

@Composable
private fun OptionRow(labelRes: Int, key: String) {
    val ctx = LocalContext.current
    var v by remember { mutableStateOf(Prefs.get(ctx, key, true)) }
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(stringResource(labelRes), fontSize = 15.sp, modifier = Modifier.weight(1f))
        Switch(checked = v, onCheckedChange = {
            v = it
            Prefs.set(ctx, key, it)
            Live.optionChanged(ctx)
        })
    }
}

@Composable
private fun TorchCard() {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, Prefs.K_TORCH)) }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    GlassCard {
        TweakHeader(R.string.tweak_torch_name, on) { want ->
            if (want) {
                if (Build.VERSION.SDK_INT >= 33 &&
                    ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                Prefs.set(ctx, Prefs.K_TORCH, true)
                TorchService.start(ctx)
            } else {
                Prefs.set(ctx, Prefs.K_TORCH, false)
                TorchService.stop(ctx)
            }
            on = want
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.tweak_torch_desc), fontSize = 14.sp, color = Dim)
        Spacer(Modifier.height(6.dp))
        Text(stringResource(R.string.torch_hint), fontSize = 12.sp, color = Dim)
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun GravityCard(
    nameRes: Int,
    descRes: Int,
    key: String,
    target: Class<*>
) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, key)) }

    GlassCard {
        TweakHeader(nameRes, on) {
            Prefs.set(ctx, key, it)
            Prefs.refreshTile(ctx)
            on = it
        }
        Spacer(Modifier.height(6.dp))
        Text(stringResource(descRes), fontSize = 14.sp, color = Dim)
        if (on) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { ctx.startActivity(Intent(ctx, target)) },
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HyperBlue, contentColor = Color.White)
                ) { Text(stringResource(R.string.open)) }
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                }) { Text(stringResource(R.string.choose_home)) }
            }
            Spacer(Modifier.height(6.dp))
            Text(stringResource(R.string.grav_hint), fontSize = 12.sp, color = Dim)
        }
        Spacer(Modifier.height(10.dp))
    }
}

// ───────────────────────── Настройки ─────────────────────────

@Composable
fun SettingsScreen(onBack: () -> Unit, onLanguageChanged: () -> Unit, onRemoved: () -> Unit) {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Prefs.lang(ctx)) }
    var confirm by remember { mutableStateOf(false) }
    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: ""
        } catch (_: Throwable) {
            ""
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 4.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.settings),
                style = TextStyle(
                    brush = Brush.horizontalGradient(
                        listOf(Color(0xFF7FA8FF), Color(0xFFB69BFF), Color(0xFFD7A5FF))
                    ),
                    fontSize = 34.sp,
                    fontWeight = FontWeight.Bold
                ),
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 8.dp)
            )
            GlassPill(stringResource(R.string.back), onBack)
        }

        SectionLabel(stringResource(R.string.language))
        GlassCard {
            LangRow(stringResource(R.string.lang_ru), lang == "ru") {
                if (lang != "ru") {
                    Prefs.setLang(ctx, "ru"); lang = "ru"; onLanguageChanged()
                }
            }
            Hairline()
            LangRow(stringResource(R.string.lang_en), lang == "en") {
                if (lang != "en") {
                    Prefs.setLang(ctx, "en"); lang = "en"; onLanguageChanged()
                }
            }
        }

        Spacer(Modifier.height(6.dp))
        Button(
            onClick = { confirm = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HyperRed, contentColor = Color.White)
        ) {
            Text(stringResource(R.string.remove_jb), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(
            stringResource(R.string.remove_jb_hint),
            fontSize = 13.sp,
            color = Dim,
            modifier = Modifier.padding(horizontal = 12.dp)
        )

        Spacer(Modifier.height(16.dp))
        Text(
            "${stringResource(R.string.app_name)} $version",
            fontSize = 13.sp,
            color = Dim,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
        )
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            containerColor = Color(0xFF1B1E4B),
            title = { Text(stringResource(R.string.remove_title)) },
            text = { Text(stringResource(R.string.remove_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    Prefs.removeJailbreak(ctx)
                    onRemoved()
                }) { Text(stringResource(R.string.remove), color = HyperRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun LangRow(title: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (selected) Text("✓", fontSize = 20.sp, color = HyperBlue, fontWeight = FontWeight.Bold)
    }
}
