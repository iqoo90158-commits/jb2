package com.example.jailbreak

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private val HyperBlue = Color(0xFF3482FF)
private val HyperRed = Color(0xFFE5484D)

class MainActivity : ComponentActivity() {

    private val resumeTick = mutableIntStateOf(0)

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(LocaleHelper.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            HyperTheme {
                AppRoot(resumeTick.intValue, onLanguageChanged = { recreate() })
            }
        }
    }

    override fun onResume() {
        super.onResume()
        resumeTick.intValue++
    }
}

// ───────────────────────── Тема в духе HyperOS ─────────────────────────

@Composable
fun HyperTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) {
        darkColorScheme(
            primary = HyperBlue,
            background = Color(0xFF000000),
            surface = Color(0xFF1C1C1E),
            onBackground = Color(0xFFF2F2F7),
            onSurface = Color(0xFFF2F2F7),
            onSurfaceVariant = Color(0xFF9A9AA0),
            surfaceVariant = Color(0xFF2C2C2E)
        )
    } else {
        lightColorScheme(
            primary = HyperBlue,
            background = Color(0xFFF2F3F5),
            surface = Color(0xFFFFFFFF),
            onBackground = Color(0xFF111111),
            onSurface = Color(0xFF111111),
            onSurfaceVariant = Color(0xFF8A8A8F),
            surfaceVariant = Color(0xFFEDEEF1)
        )
    }
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun HCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(20.dp),
        content = content
    )
}

// ───────────────────────── Навигация ─────────────────────────

@Composable
fun AppRoot(tick: Int, onLanguageChanged: () -> Unit) {
    val ctx = LocalContext.current
    var screen by remember { mutableIntStateOf(0) }
    var jb by remember { mutableStateOf(Prefs.jailbroken(ctx)) }

    BackHandler(screen == 1) { screen = 0 }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (screen == 0) {
            HomeScreen(
                jb = jb,
                tick = tick,
                onJailbroken = { jb = true },
                onSettings = { screen = 1 }
            )
        } else {
            SettingsScreen(
                onBack = { screen = 0 },
                onLanguageChanged = onLanguageChanged,
                onRemoved = { jb = false; screen = 0 }
            )
        }
    }
}

// ───────────────────────── Главный экран ─────────────────────────

@Composable
fun HomeScreen(jb: Boolean, tick: Int, onJailbroken: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    val info = remember(tick) { DeviceInfo.collect(ctx) }
    val scope = rememberCoroutineScope()

    var running by remember { mutableStateOf(false) }
    var step by remember { mutableIntStateOf(0) }
    val steps = listOf(R.string.step_1, R.string.step_2, R.string.step_3)

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Заголовок + шестерёнка
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.app_name),
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { onSettings() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(stringResource(R.string.settings), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }

        // Карточка устройства
        HCard {
            Text(info.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(2.dp))
            Text(info.os, fontSize = 15.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }

        // Параметры устройства
        Text(
            stringResource(R.string.device_info),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 12.dp)
        )
        HCard(Modifier, content = {
            info.rows.forEachIndexed { i, (label, value) ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text(
                        stringResource(label),
                        fontSize = 15.sp,
                        modifier = Modifier.weight(0.42f)
                    )
                    Text(
                        value,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.weight(0.58f)
                    )
                }
                if (i < info.rows.lastIndex) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(1.dp)
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    )
                }
            }
        })

        // Кнопка джейлбрейка
        Button(
            onClick = {
                if (jb || running) return@Button
                scope.launch {
                    running = true
                    for (i in steps.indices) {
                        step = i
                        delay(900)
                    }
                    Prefs.set(ctx, Prefs.K_JB, true)
                    Prefs.refreshTile(ctx)
                    running = false
                    onJailbroken()
                }
            },
            enabled = !jb && !running,
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp),
            shape = RoundedCornerShape(30.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = HyperBlue,
                contentColor = Color.White,
                disabledContainerColor = if (jb) Color(0xFF34C759) else HyperBlue.copy(alpha = 0.55f),
                disabledContentColor = Color.White
            )
        ) {
            Text(
                when {
                    running -> stringResource(steps[step])
                    jb -> stringResource(R.string.btn_done)
                    else -> stringResource(R.string.btn_jailbreak)
                },
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        if (running) {
            LinearProgressIndicator(
                progress = { (step + 1) / steps.size.toFloat() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                color = HyperBlue
            )
        }

        // Твики
        if (jb) {
            Text(
                stringResource(R.string.tweaks),
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(start = 12.dp, top = 6.dp)
            )
            LalaCard(tick)
            GravityCard(
                nameRes = R.string.tweak_grav_name,
                descRes = R.string.tweak_grav_desc,
                key = Prefs.K_GRAV,
                target = GravityActivity::class.java,
                showHint = true
            )
            GravityCard(
                nameRes = R.string.tweak_lite_name,
                descRes = R.string.tweak_lite_desc,
                key = Prefs.K_LITE,
                target = GravityLiteActivity::class.java,
                showHint = false
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

// ───────────────────────── Карточки твиков ─────────────────────────

@Composable
private fun TweakHeader(nameRes: Int, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            stringResource(nameRes),
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.weight(1f)
        )
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun LalaCard(tick: Int) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, Prefs.K_LALA)) }
    val hasOverlay = remember(tick) { Settings.canDrawOverlays(ctx) }
    val hasNotifAccess = remember(tick) {
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)
    }
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}

    HCard {
        TweakHeader(R.string.tweak_lala_name, on) { want ->
            if (want) {
                if (!Settings.canDrawOverlays(ctx)) {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                } else {
                    if (Build.VERSION.SDK_INT >= 33 &&
                        ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                    ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    Prefs.set(ctx, Prefs.K_LALA, true)
                    IslandService.start(ctx)
                    on = true
                }
            } else {
                Prefs.set(ctx, Prefs.K_LALA, false)
                IslandService.stop(ctx)
                on = false
            }
        }
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(R.string.tweak_lala_desc),
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (!hasOverlay) {
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    stringResource(R.string.overlay_needed),
                    fontSize = 13.sp,
                    color = HyperRed,
                    modifier = Modifier.weight(1f)
                )
                TextButton(onClick = {
                    ctx.startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${ctx.packageName}")
                        )
                    )
                }) { Text(stringResource(R.string.grant)) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                stringResource(if (hasNotifAccess) R.string.notif_access_on else R.string.notif_access),
                fontSize = 13.sp,
                modifier = Modifier.weight(1f)
            )
            if (!hasNotifAccess) {
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
                }) { Text(stringResource(R.string.grant)) }
            }
        }
    }
}

@Composable
private fun GravityCard(
    nameRes: Int,
    descRes: Int,
    key: String,
    target: Class<*>,
    showHint: Boolean
) {
    val ctx = LocalContext.current
    var on by remember { mutableStateOf(Prefs.get(ctx, key)) }

    HCard {
        TweakHeader(nameRes, on) {
            Prefs.set(ctx, key, it)
            Prefs.refreshTile(ctx)
            on = it
        }
        Spacer(Modifier.height(6.dp))
        Text(
            stringResource(descRes),
            fontSize = 14.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (on) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = { ctx.startActivity(Intent(ctx, target)) },
                    shape = RoundedCornerShape(22.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = HyperBlue)
                ) { Text(stringResource(R.string.open)) }
                TextButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
                }) { Text(stringResource(R.string.choose_home)) }
            }
            if (showHint) {
                Spacer(Modifier.height(6.dp))
                Text(
                    stringResource(R.string.grav_hint),
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ───────────────────────── Настройки ─────────────────────────

@Composable
fun SettingsScreen(onBack: () -> Unit, onLanguageChanged: () -> Unit, onRemoved: () -> Unit) {
    val ctx = LocalContext.current
    var lang by remember { mutableStateOf(Prefs.lang(ctx)) }
    var confirm by remember { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 8.dp, top = 8.dp, bottom = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                stringResource(R.string.settings),
                fontSize = 34.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.weight(1f)
            )
            Box(
                Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.surface)
                    .clickable { onBack() }
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(stringResource(R.string.back), fontSize = 15.sp, fontWeight = FontWeight.Medium)
            }
        }

        Text(
            stringResource(R.string.language),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(start = 12.dp)
        )
        HCard {
            LangRow(stringResource(R.string.lang_ru), lang == "ru") {
                if (lang != "ru") {
                    Prefs.setLang(ctx, "ru"); lang = "ru"; onLanguageChanged()
                }
            }
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(MaterialTheme.colorScheme.surfaceVariant)
            )
            LangRow(stringResource(R.string.lang_en), lang == "en") {
                if (lang != "en") {
                    Prefs.setLang(ctx, "en"); lang = "en"; onLanguageChanged()
                }
            }
        }

        Button(
            onClick = { confirm = true },
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(28.dp),
            colors = ButtonDefaults.buttonColors(containerColor = HyperRed, contentColor = Color.White)
        ) {
            Text(stringResource(R.string.remove_jb), fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        }
        Text(
            stringResource(R.string.remove_jb_hint),
            fontSize = 13.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
    }

    if (confirm) {
        AlertDialog(
            onDismissRequest = { confirm = false },
            title = { Text(stringResource(R.string.remove_title)) },
            text = { Text(stringResource(R.string.remove_text)) },
            confirmButton = {
                TextButton(onClick = {
                    confirm = false
                    Prefs.removeJailbreak(ctx)
                    onRemoved()
                }) { Text(stringResource(R.string.remove), color = HyperRed) }
            },
            dismissButton = {
                TextButton(onClick = { confirm = false }) { Text(stringResource(R.string.cancel)) }
            }
        )
    }
}

@Composable
private fun LangRow(title: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, fontSize = 17.sp, modifier = Modifier.weight(1f))
        if (selected) Text("✓", fontSize = 20.sp, color = HyperBlue, fontWeight = FontWeight.Bold)
    }
}
