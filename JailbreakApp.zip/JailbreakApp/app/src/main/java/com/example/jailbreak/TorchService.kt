package com.example.jailbreak

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.sqrt

/**
 * Torch: три резких встряхивания показывают всплывающее подтверждение
 * «Включить фонарик?» с кнопками «Да» и «Нет». Случайные толчки больше
 * не включают фонарик сами по себе.
 */
class TorchService : Service(), SensorEventListener {

    companion object {
        fun start(c: Context) {
            c.startForegroundService(Intent(c, TorchService::class.java))
        }

        fun stop(c: Context) {
            c.stopService(Intent(c, TorchService::class.java))
        }
    }

    private lateinit var sm: SensorManager
    private lateinit var cm: CameraManager
    private var camId: String? = null
    private var torchOn = false
    private var usingLinear = true

    private val hits = ArrayDeque<Long>()
    private var lastSpike = 0L
    private var lastToggle = 0L
    private var gX = 0f
    private var gY = 0f
    private var gZ = 0f

    private val main = Handler(Looper.getMainLooper())
    private var popup: View? = null

    private val torchCb = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == camId) torchOn = enabled
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        cm = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            camId = cm.cameraIdList.firstOrNull { id ->
                cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            cm.registerTorchCallback(torchCb, null)
        } catch (_: Throwable) {
        }
        val lin = sm.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)
        usingLinear = lin != null
        val s = lin ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        s?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("torch", getString(R.string.tweak_torch_name), NotificationManager.IMPORTANCE_MIN)
        )
        val n = Notification.Builder(this, "torch")
            .setSmallIcon(R.drawable.ic_tile)
            .setContentTitle(getString(R.string.torch_running))
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(2, n)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        var x = e.values[0]
        var y = e.values[1]
        var z = e.values[2]
        if (!usingLinear) {
            // убираем силу тяжести обычным фильтром
            gX = 0.8f * gX + 0.2f * x
            gY = 0.8f * gY + 0.2f * y
            gZ = 0.8f * gZ + 0.2f * z
            x -= gX; y -= gY; z -= gZ
        }
        val mag = sqrt(x * x + y * y + z * z)
        val now = SystemClock.elapsedRealtime()

        // резкий толчок: заметно сильнее ходьбы
        if (mag > 17f && now - lastSpike > 110) {
            lastSpike = now
            hits.addLast(now)
            while (hits.isNotEmpty() && now - hits.first() > 1000) hits.removeFirst()
            if (hits.size >= 3 && now - lastToggle > 2000) {
                hits.clear()
                askToggle()
            }
        }
    }

    /** Спрашивает подтверждение, а не включает фонарик сразу. */
    private fun askToggle() {
        val want = !torchOn
        lastToggle = SystemClock.elapsedRealtime()
        main.post {
            val title = getString(
                if (want) R.string.torch_ask_on else R.string.torch_ask_off
            )
            val result = getString(if (want) R.string.torch_on else R.string.torch_off)

            if (!Settings.canDrawOverlays(this)) {
                // без оверлея диалог не показать: работаем как раньше, но с тостом
                doToggle(want)
                Toast.makeText(this, result, Toast.LENGTH_SHORT).show()
                return@post
            }

            hidePopup()
            val v = ConfirmPopup(
                this,
                title,
                getString(R.string.yes),
                getString(R.string.no)
            ) { ok ->
                hidePopup()
                if (ok) {
                    doToggle(want)
                    showResult(result)
                }
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = (150 * resources.displayMetrics.density).toInt()
            }
            if (addOverlay(v, lp)) {
                v.show()
                v.autoHide(8000)
            } else {
                doToggle(want)
            }
        }
    }

    private fun doToggle(want: Boolean) {
        val id = camId ?: return
        try {
            cm.setTorchMode(id, want)
        } catch (_: Throwable) {
            return
        }
        torchOn = want
        vibrate()
    }

    private fun vibrate() {
        try {
            @Suppress("DEPRECATION")
            val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vib?.vibrate(VibrationEffect.createOneShot(40, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {
        }
    }

    /** Короткое подтверждение «Фонарик включён / выключен». */
    private fun showResult(text: String) {
        main.post {
            if (!Settings.canDrawOverlays(this)) return@post
            hidePopup()
            val v = PopupView(this, text)
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                y = (110 * resources.displayMetrics.density).toInt()
            }
            if (addOverlay(v, lp)) v.fadeOut { hidePopup() }
        }
    }

    private fun addOverlay(v: View, lp: WindowManager.LayoutParams): Boolean = try {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm.addView(v, lp)
        popup = v
        true
    } catch (_: Throwable) {
        false
    }

    private fun hidePopup() {
        val v = popup ?: return
        popup = null
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDestroy() {
        try {
            sm.unregisterListener(this)
            cm.unregisterTorchCallback(torchCb)
        } catch (_: Throwable) {
        }
        hidePopup()
        super.onDestroy()
    }
}

/** Всплывающее окошко «Включить фонарик?» с кнопками «Да» и «Нет». */
private class ConfirmPopup(
    ctx: Context,
    title: String,
    yesText: String,
    noText: String,
    private val onAnswer: (Boolean) -> Unit
) : LinearLayout(ctx) {

    private val d = resources.displayMetrics.density
    private var answered = false

    private fun dp(v: Int) = (v * d).toInt()

    init {
        orientation = LinearLayout.VERTICAL
        minimumWidth = dp(240)
        setPadding(dp(20), dp(16), dp(20), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(Color.argb(246, 28, 30, 60))
            setStroke(dp(1), Color.argb(90, 255, 255, 255))
        }
        alpha = 0f
        scaleX = 0.92f
        scaleY = 0.92f

        addView(TextView(ctx).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, 0, 0, dp(6))
        })

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        row.addView(action(ctx, noText, false) { answer(false) })
        row.addView(action(ctx, yesText, true) { answer(true) })
        addView(row)
    }

    private fun action(ctx: Context, text: String, accent: Boolean, tap: () -> Unit): TextView =
        TextView(ctx).apply {
            this.text = text
            textSize = 15f
            setTextColor(if (accent) Color.rgb(122, 200, 255) else Color.argb(200, 255, 255, 255))
            setPadding(dp(18), dp(12), dp(18), dp(12))
            isClickable = true
            setOnClickListener { tap() }
        }

    fun show() {
        animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(170).start()
    }

    /** Если не ответили за [ms] — считаем, что «Нет». */
    fun autoHide(ms: Long) {
        postDelayed({ if (!answered) answer(false) }, ms)
    }

    private fun answer(ok: Boolean) {
        if (answered) return
        answered = true
        animate().alpha(0f).setDuration(110).withEndAction { onAnswer(ok) }.start()
    }
}

/** Короткое всплывающее подтверждение действия. */
private class PopupView(ctx: Context, text: String) : TextView(ctx) {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    init {
        setText(text)
        setTextColor(Color.WHITE)
        textSize = 14f
        setPadding(dp(20), dp(12), dp(20), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(24).toFloat()
            setColor(Color.argb(238, 28, 30, 60))
            setStroke(dp(1), Color.argb(70, 255, 255, 255))
        }
    }

    fun fadeOut(onEnd: () -> Unit) {
        alpha = 0f
        animate().alpha(1f).setDuration(140).withEndAction {
            postDelayed({
                animate().alpha(0f).setDuration(220).withEndAction { onEnd() }.start()
            }, 900)
        }.start()
    }
}
