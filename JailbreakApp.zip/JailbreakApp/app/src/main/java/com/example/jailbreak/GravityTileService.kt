package com.example.jailbreak

import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** Плитка быстрых настроек: включает и выключает гравитацию. */
class GravityTileService : TileService() {

    override fun onStartListening() = update()

    override fun onClick() {
        if (!available()) return
        Prefs.set(this, Prefs.K_GRAV_ON, !Prefs.gravityOn(this))
        update()
    }

    private fun available() =
        Prefs.jailbroken(this) && (Prefs.get(this, Prefs.K_GRAV) || Prefs.get(this, Prefs.K_LITE))

    private fun update() {
        val t = qsTile ?: return
        t.label = getString(R.string.tweak_grav_name)
        t.state = when {
            !available() -> Tile.STATE_UNAVAILABLE
            Prefs.gravityOn(this) -> Tile.STATE_ACTIVE
            else -> Tile.STATE_INACTIVE
        }
        t.updateTile()
    }
}
